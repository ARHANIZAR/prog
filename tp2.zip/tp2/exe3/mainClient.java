import java.net.*;
import java.io.*;
import java.util.*;

public class mainClient{
	public static void main(String [] args){
		int port;
		String serverAdress;
		AireClient aireClient = null;
		BufferedReader br;
		int idReq;
		String line = "";
		String [] params;

		

		if(args.length != 2) {
			System.out.println("usage : mainClient serverAdress port");
			System.exit(1);
		}
		try{
			System.out.println("insérez le nombre de forme à traiter : ");
			br = new BufferedReader(new InputStream(System.in));
			int nbForm = Integer.parseInt(br.readLine());

			for (int i = 0; i < nbForm; i++){
				line = br.readLine();
				if(line.isEmpty()){
					System.exit(1);
				}else{
					params = line.split(",");

					System.out.println(params[0]);
				}


			}
			idreq = Integer.parseInt(br.readLine());
			if(idReq == 1){
				port = Integer.parseInt(args[1]);
				serverAdress = args[0];
				double rayon = Double.parseDouble(args[2]);
				aireClient = new AireClient(serverAdress,port,rayon);
			}else if(args.length == 4){
				port = Integer.parseInt(args[1]);
				serverAdress = args[0];
				double largeur = Double.parseDouble(args[2]);
				double longeur = Double.parseDouble(args[3]);
				aireClient = new AireClient(serverAdress,port,largeur,longeur);

			}

			//aireClient.requestLoop();


		}catch(IOException e){
			System.out.println(e.getMessage());
		}catch(PaternSyntaxException ex){
			System.out.println("erreur Syntaxe de largeur/longeur ");
		}

	}
}